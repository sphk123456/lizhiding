// pages/lvzhifang.wxml.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    curTime:'',
    temp:true,
    out:true,
    urlOut:"出校登记成功",
    urlIn:"入校登记成功"
  },

  getFormatDate(){
    var nowDate = new Date();
    var year = nowDate.getFullYear();
    var month = nowDate.getMonth() + 1 < 10 ? "0" + (nowDate.getMonth() + 1) : nowDate.getMonth() + 1;
    var date = nowDate.getDate() < 10 ? "0" + nowDate.getDate() : nowDate.getDate();
    var hour = nowDate.getHours()< 10 ? "0" + nowDate.getHours() : nowDate.getHours();
    var minute = nowDate.getMinutes()< 10 ? "0" + nowDate.getMinutes() : nowDate.getMinutes();
    var second = nowDate.getSeconds()< 10 ? "0" + nowDate.getSeconds() : nowDate.getSeconds();
    return year + "-" + month + "-" + date+" "+hour+":"+minute+":"+second;
  },
  /**
   * 生命周期函数--监听页面加载
   */


/**
 * 生命周期函数--监听页面加载
 */
onLoad(options) {
  console.log(options.out)
  this.setData({out:options.out==="true"?true:false})
  console.log('onLoad temp',this.data.temp)
  console.log('onLoad out',this.data.out)
},

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {
    console.log(this.getFormatDate())
    let time = (this.getFormatDate()).toString() + ' '
    let res = ''
    for(let i =0;i<10;i++){
      res += (time+' ')
    }
    console.log(res)
    this.setData({curTime:res})
    wx.setNavigationBarTitle({
      title: "平安成电智慧通行"
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})