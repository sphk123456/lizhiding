// pages/vxIndex.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isOpen: false,
    displayBlock:"eject-box display-block",
    displayNone:"eject-box display-none",
  },
  plusClick: function () {
    let curOpen = this.data.isOpen
    this.setData({isOpen:!curOpen})
    // this.data.isOpen = 
    // console.log(this.data.isOpen)
    // let query = wx.createSelectorQuery()
    // let ejectBox = query.select(".eject-box").boundingClientRect(res=>{
    //   console.log(res)
    // })
    // query.exec(res=>{})
  
    // console.log(ejectBox)
    // // 显示弹出层
    // if(this.data.isOpen){
    //   let ejectBox = document.getElementsByClassName("eject-box")[0]
    //   ejectBox.className = "eject-box display-block"
    // }
    

    // 关闭弹出层
  },
  ejectClick: function (event) {
    console.log((wx.getSystemInfoSync().windowWidth)*0.8)
    console.log(event.touches[0].pageX)
    let cur = event.touches[0].pageX < (wx.getSystemInfoSync().windowWidth)*0.8?false:true
    //扫描API
    wx.scanCode({
      //扫描成功
      success(res) {
        wx.navigateTo({
          url: '../scanres/scanres?out='+cur
          // url: '../lvzhifang/lvzhifang?out='+cur
        })
      },
      fail: (res) => { //接口调用失败的回调函数
        // wx.showToast({
        //   title: '扫码失败',
        //   icon: 'success',
        //   duration: 1000
        // })
      },
    })

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({isOpen:false})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({isOpen:false})
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    this.setData({isOpen:false})
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})